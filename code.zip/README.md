
# Predicting RNA Proteins binding sites Using Global and Local CNNs

Predicitng RNA-protein binding sites has traditionally relied on labor-intensive experimental methods. Given the
scalability challenges of such methods, computational models, notably deep learning techniques, have emerged as promising alternatives. However, so far these techniques have only used global sequences, the full sequence, of RNAs. Although local sequences have a great biological significance in the RNA-protein interactions, as they are integral in determining the specificity of binding sites, thus enriching our understanding of protein-RNA affinities. Our work reimplements the work of Pan and Shen (2018) that  the integrates of both local and global convolutional neural networks (CNNs) to discern structural attributes of RNA, facilitating a comprehensive analysis of RNA-protein interactions. This approach aims to enhance
the accuracy of RNA binding sites predictions by integrating local and global RNA sequences.




# Dependency:

Python 3.1 \
Jupyterlab Notebook \
DeepNet server



## Data
Download the trainig and testing data from http://www.bioinf.uni-freiburg.de/Software/GraphProt/GraphProt_CLIP_sequences.tar.bz2 and decompress it in current dir. It is Clip-Seq dataset rhat has 24 experiments of 21 RBPs, and we need train one model per experiment.
## Usage

Call the function RunModel with the arguments:**(posi, nega, model_type, ensemble, out_file,train, model_file, predict, max_size, 
channel, local, window_size=101,batch_size, n_epochs, num_filters, testfile, glob, testfile2)**

**posi:** positive training data \
**nega:** negative training data \
**ensemble:** True if we want to ensemble the glbal and local models results\
**out_file:** output file for the predictions\
**max_size:** maximum sequence length\
**channel:** 1 for global , 7 for local

## Use Case
Consider ALKBH5, to identify the binding sites for the RNA-binding protein (RBP) ALKBH5 using a combination of local and global Convolutional Neural Networks (CNNs), where the primary approach is an ensemble model, here's what you'd do:
First, train the ensemble model specifically for the RBP ALKBH5. Once the training is complete, you can use the trained model to estimate the binding probabilities of this RBP on your given sequences.
## Reference
Eman Ansar^, Sara Zewil^. 
reimplemented Pan and Shen (2018)

